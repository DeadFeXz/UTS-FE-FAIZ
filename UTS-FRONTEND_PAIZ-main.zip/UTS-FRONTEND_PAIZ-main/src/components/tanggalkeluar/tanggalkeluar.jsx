import React, { useState, useEffect } from 'react';
import axios from 'axios';

function TanggalKeluar() {
  const [tanggalKeluars, setTanggalKeluars] = useState([]);
  const [newTanggalKeluar, setNewTanggalKeluar] = useState({ tanggal: '' });
  const [editingTanggalKeluar, setEditingTanggalKeluar] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchTanggalKeluars();
  }, []);

  const fetchTanggalKeluars = async () => {
    try {
      const response = await axios.get('http://localhost:3005/Keluar');
      console.log('Fetched exit dates:', response.data);
      setTanggalKeluars(response.data);
    } catch (error) {
      console.error('Error fetching exit dates:', error);
      setError('Failed to fetch exit dates. Please try again.');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (editingTanggalKeluar) {
      setEditingTanggalKeluar({ ...editingTanggalKeluar, [name]: value });
    } else {
      setNewTanggalKeluar({ ...newTanggalKeluar, [name]: value });
    }
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!newTanggalKeluar.tanggal) {
      alert('Please select a date before adding.');
      return;
    }
    try {
      await axios.post('http://localhost:3005/Keluar/create', newTanggalKeluar);
      setNewTanggalKeluar({ tanggal: '' });
      fetchTanggalKeluars();
      handleCloseModal();
    } catch (error) {
      console.error('Error adding exit date:', error);
    }
  };

  const handleEdit = (tanggalKeluar) => {
    console.log('Editing exit date:', tanggalKeluar);
    setEditingTanggalKeluar({ ...tanggalKeluar });
    setShowModal(true);
  };

  const handleUpdate = async () => {
    if (!editingTanggalKeluar || !editingTanggalKeluar.id) {
      console.error('Editing exit date or ID is undefined');
      return;
    }
    console.log('Updating exit date with ID:', editingTanggalKeluar.id);
    try {
      const response = await axios.put(`http://localhost:3005/Keluar/update/${editingTanggalKeluar.id}`, editingTanggalKeluar);
      if (response.status === 200) {
        console.log('Exit date updated successfully:', response.data);
        setEditingTanggalKeluar(null);
        fetchTanggalKeluars();
        handleCloseModal();
      } else {
        console.error('Update failed with status:', response.status);
      }
    } catch (error) {
      console.error('Error updating exit date:', error.response ? error.response.data : error.message);
    }
  };

  const handleDelete = async (id) => {
    if (!id) {
      console.error('Exit date ID is undefined or null');
      return;
    }
    try {
      console.log('Attempting to delete exit date with ID:', id);
      const response = await axios.delete(`http://localhost:3005/Keluar/delete/${id}`);
      if (response.status === 200) {
        console.log('Exit date deleted successfully');
        fetchTanggalKeluars();
      } else {
        console.error('Error deleting exit date:', response);
      }
    } catch (error) {
      console.error('Error in delete request:', error);
    }
  };

  const handleShowModal = () => {
    setShowModal(true);
    setEditingTanggalKeluar(null);
    setNewTanggalKeluar({ tanggal: '' });
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingTanggalKeluar(null);
    setNewTanggalKeluar({ tanggal: '' });
  };

  return (
    <div className="container mx-auto px-4 mt-8">
      <h1 className="text-3xl font-bold mb-4">Tanggal Keluar</h1>
      <button
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4"
        onClick={handleShowModal}
      >
        Add Tanggal Keluar
      </button>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {tanggalKeluars.map(tanggalKeluar => (
              <tr key={tanggalKeluar.id}>
                <td className="px-6 py-4 whitespace-nowrap">{tanggalKeluar.tanggal}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <button
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded mr-2"
                    onClick={() => handleEdit(tanggalKeluar)}
                  >
                    Edit
                  </button>
                  <button
                    className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded"
                    onClick={() => handleDelete(tanggalKeluar.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3 text-center">
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                {editingTanggalKeluar ? 'Edit Tanggal Keluar' : 'Add Tanggal Keluar'}
              </h3>
              <form className="mt-2 text-left" onSubmit={editingTanggalKeluar ? handleUpdate : handleAdd}>
                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="tanggal">
                    Tanggal
                  </label>
                  <input
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    type="date" // Use 'date' type for date input
                    name="tanggal"
                    value={editingTanggalKeluar ? editingTanggalKeluar.tanggal : newTanggalKeluar.tanggal}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="flex items-center justify-between">
                <button
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="button"
                    onClick={editingTanggalKeluar ? handleUpdate : handleAdd}
                  >
                    {editingTanggalKeluar ? 'Update' : 'Add'}
                  </button>
                  <button
                    className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="button"
                    onClick={handleCloseModal}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default TanggalKeluar;
