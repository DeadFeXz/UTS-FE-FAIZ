import React, { useState, useEffect } from 'react';
import axios from 'axios';

function TanggalMasuk() {
  const [tanggalMasuks, setTanggalMasuks] = useState([]);
  const [newTanggalMasuk, setNewTanggalMasuk] = useState({ tanggal: '' });
  const [editingTanggalMasuk, setEditingTanggalMasuk] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchTanggalMasuks();
  }, []);

  const fetchTanggalMasuks = async () => {
    try {
      const response = await axios.get('http://localhost:3005/Masuk');
      console.log('Fetched dates:', response.data); // Log data tanggal masuk
      setTanggalMasuks(response.data);
    } catch (error) {
      console.error('Error fetching dates:', error);
      setError('Failed to fetch dates. Please try again.');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (editingTanggalMasuk) {
      setEditingTanggalMasuk({ ...editingTanggalMasuk, [name]: value });
    } else {
      setNewTanggalMasuk({ ...newTanggalMasuk, [name]: value });
    }
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!newTanggalMasuk.tanggal) {
      alert('Please fill in the date before adding.');
      return;
    }
    try {
      await axios.post('http://localhost:3005/Masuk/create', {
        tanggal: newTanggalMasuk.tanggal // Send date as a string
      });
      setNewTanggalMasuk({ tanggal: '' });
      fetchTanggalMasuks();
      handleCloseModal(); // Close modal after adding date
    } catch (error) {
      console.error('Error adding date:', error);
    }
  };

  const handleEdit = (tanggalMasuk) => {
    console.log('Editing date:', tanggalMasuk);
    setEditingTanggalMasuk({ ...tanggalMasuk, tanggalMasukId: tanggalMasuk.id });
    setShowModal(true);
  };

  const handleUpdate = async () => {
    if (!editingTanggalMasuk || !editingTanggalMasuk.tanggalMasukId) {
      console.error('Editing date or date ID is undefined');
      return;
    }

    try {
      const response = await axios.put(`http://localhost:3005/Masuk/update/${editingTanggalMasuk.tanggalMasukId}`, {
        tanggal: editingTanggalMasuk.tanggal // Send date as a string
      });

      if (response.status === 200) {
        console.log('Date updated successfully:', response.data);
        setEditingTanggalMasuk(null);
        fetchTanggalMasuks();
        handleCloseModal();
      } else {
        console.error('Update failed with status:', response.status, response.data);
      }
    } catch (error) {
      console.error('Error updating date:', error.response ? error.response.data : error.message);
    }
  };

  const handleDelete = async (id) => {
    if (!id) {
      console.error('Date ID is undefined or null');
      return;
    }

    try {
      console.log('Attempting to delete date with ID:', id);
      const response = await axios.delete(`http://localhost:3005/Masuk/delete/${id}`);

      if (response.status === 200) {
        console.log('Date deleted successfully');
        fetchTanggalMasuks();
      } else {
        console.error('Error deleting date:', response);
      }
    } catch (error) {
      console.error('Error in delete request:', error);
    }
  };

  const handleShowModal = () => {
    setShowModal(true);
    setEditingTanggalMasuk(null);
    setNewTanggalMasuk({ tanggal: '' });
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingTanggalMasuk(null);
    setNewTanggalMasuk({ tanggal: '' });
  };

  return (
    <div className="container mx-auto px-4 mt-8">
      <h1 className="text-3xl font-bold mb-4">Tanggal Masuk List</h1>
      <button
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4"
        onClick={handleShowModal}
      >
        Add Tanggal Masuk
      </button>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {tanggalMasuks.map(tanggalMasuk => (
              <tr key={tanggalMasuk.tanggalMasukId}>
                <td className="px-6 py-4 whitespace-nowrap">{new Date(tanggalMasuk.tanggal).toLocaleDateString()}</td> {/* Format date */}
                <td className="px-6 py-4 whitespace-nowrap">
                  <button
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded mr-2"
                    onClick={() => handleEdit(tanggalMasuk)}
                  >
                    Edit
                  </button>
                  <button
                    className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded"
                    onClick={() => handleDelete(tanggalMasuk.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3 text-center">
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                {editingTanggalMasuk ? 'Edit Tanggal Masuk' : 'Add Tanggal Masuk'}
              </h3>
              <form className="mt-2 text-left" onSubmit={editingTanggalMasuk ? handleUpdate : handleAdd}>
                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="tanggal">
                    Tanggal
                  </label>
                  <input
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    type="date"
                    name="tanggal"
                    value={editingTanggalMasuk ? editingTanggalMasuk.tanggal : newTanggalMasuk.tanggal}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="flex items-center justify-between">
                <button
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="button"
                    onClick={editingTanggalMasuk ? handleUpdate : handleAdd}
                  >
                    {editingTanggalMasuk ? 'Update' : 'Add'}
                  </button>
                  <button
                    className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="button"
                    onClick={handleCloseModal}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default TanggalMasuk;
